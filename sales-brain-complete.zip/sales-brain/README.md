# Sales Brain

A personal learning and insights engine for sales professionals. Transforms call transcripts into searchable institutional memory with precomputed intelligence.

## What This Is

- **Self-Coaching** — Track your patterns, talk ratios, improvement areas
- **Knowledge Accumulation** — Product info, company processes, competitor intel
- **People & Context Memory** — What everyone told you, indexed and searchable
- **Sales Intelligence** — MEDDPICC tracking, objection patterns, deal insights

## What This Is NOT

- Not a CRM
- Not pipeline management
- Not contact management

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│              CONTINUOUS BACKGROUND PROCESSOR            │
│  - Watches for new transcripts                          │
│  - Segments & tags                                      │
│  - Updates all entity profiles                          │
│  - Precomputes metrics                                  │
└─────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────┐
│              PRECOMPUTED INTELLIGENCE LAYER             │
│  Deals | People | Product | Patterns | Objections       │
│  Process | Advice | Topics                              │
└─────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────┐
│                    QUERY INTERFACE                      │
│  Fast retrieval + Claude synthesis + visualizations     │
└─────────────────────────────────────────────────────────┘
```

## Setup

```bash
# Install dependencies
npm install

# Initialize database
npm run db:init

# Start the application
npm run dev
```

## Environment Variables

Create a `.env` file:

```
ANTHROPIC_API_KEY=your_key_here
WATCH_FOLDER=./transcripts
```

## Project Structure

```
sales-brain/
├── src/
│   ├── db/              # Database schema and queries
│   ├── ingestion/       # File watching and parsing
│   ├── processing/      # Segmentation and tagging (AI)
│   ├── entities/        # Deal, Person, Product extractors
│   ├── indices/         # Precomputed intelligence layer
│   ├── api/             # Backend API routes
│   └── ui/              # React frontend
├── transcripts/         # Drop transcripts here
├── data/                # SQLite database
└── package.json
```

## Phase 1 (Current)

- [x] Database schema
- [x] Folder watcher
- [x] Transcript ingestion
- [x] Segmentation logic (stubbed)
- [x] Basic web UI

## Future Phases

- [ ] Entity extraction (deals, people, products)
- [ ] Precomputed indices
- [ ] Background processor
- [ ] Query interface with Claude
- [ ] Dynamic visualizations
- [ ] Google Drive integration
